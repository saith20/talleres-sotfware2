package com.tecnologicocomfenalco.ejercicio_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
