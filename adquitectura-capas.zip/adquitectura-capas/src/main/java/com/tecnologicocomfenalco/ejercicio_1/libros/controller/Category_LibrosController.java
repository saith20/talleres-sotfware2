package com.tecnologicocomfenalco.ejercicio_1.libros.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tecnologicocomfenalco.ejercicio_1.libros.models.dtos.Category_librosDTO;
import com.tecnologicocomfenalco.ejercicio_1.libros.service.Category_LibrosService;

@RestController
public class Category_LibrosController {

    private final Category_LibrosService category_librosService;

    public Category_LibrosController(Category_LibrosService category_librosService) {
        this.category_librosService = category_librosService;
    }

    @PostMapping("category_libros")
    public void create(Category_librosDTO category_librosDTO) {
        category_librosService.create(category_librosDTO);
    }

    @GetMapping("category_libros")
    public List<Category_librosDTO> findAll(){
        return category_librosService.findAll();
    }

}
