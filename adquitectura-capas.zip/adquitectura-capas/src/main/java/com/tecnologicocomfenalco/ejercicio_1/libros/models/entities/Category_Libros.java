package com.tecnologicocomfenalco.ejercicio_1.libros.models.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Category_Libros {
    private int id;
    private String code;
    private String name;

}
