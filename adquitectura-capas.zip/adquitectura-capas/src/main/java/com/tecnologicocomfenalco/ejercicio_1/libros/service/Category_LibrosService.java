package com.tecnologicocomfenalco.ejercicio_1.libros.service;


import java.util.List;

import com.tecnologicocomfenalco.ejercicio_1.libros.models.dtos.Category_librosDTO;


public interface Category_LibrosService {
    void create(Category_librosDTO category_librosDTO);
    List<Category_librosDTO> findAll();
    
}

