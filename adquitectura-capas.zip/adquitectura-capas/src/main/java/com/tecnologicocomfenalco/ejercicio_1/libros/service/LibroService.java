package com.tecnologicocomfenalco.ejercicio_1.libros.service;

import java.util.List;

import com.tecnologicocomfenalco.ejercicio_1.libros.models.dtos.LibroDTO;

public interface LibroService {

    List<LibroDTO> findAll();
}





