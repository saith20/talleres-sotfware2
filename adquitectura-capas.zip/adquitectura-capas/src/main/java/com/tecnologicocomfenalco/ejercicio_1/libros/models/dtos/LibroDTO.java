
package com.tecnologicocomfenalco.ejercicio_1.libros.models.dtos;

import java.util.List;


import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class LibroDTO {
    private String name;
    private int quantity;
    private List<Category_librosDTO> categories;
    

}
