package com.tecnologicocomfenalco.ejercicio_1.libros.models.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Category_librosDTO {
    private String code;
    private String name;


}
