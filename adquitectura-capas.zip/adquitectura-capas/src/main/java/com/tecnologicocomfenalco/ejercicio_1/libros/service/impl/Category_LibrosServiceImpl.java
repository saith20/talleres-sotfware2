package com.tecnologicocomfenalco.ejercicio_1.libros.service.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.tecnologicocomfenalco.ejercicio_1.libros.models.dtos.Category_librosDTO;
import com.tecnologicocomfenalco.ejercicio_1.libros.service.Category_LibrosService;

@Service
public class Category_LibrosServiceImpl implements Category_LibrosService {

    @Override
    public void create(Category_librosDTO category_libros) {
        System.out.println("Crear");
    }

    @Override
    public List<Category_librosDTO> findAll() {
        List<Category_librosDTO> list= Arrays.asList(
            new Category_librosDTO("001", "Comedia"),
            new Category_librosDTO("002", "Romance"),
            new Category_librosDTO("003", "Novela"),
            new Category_librosDTO("004", "Ciencia ficcion"),
            new Category_librosDTO("005", "Otros")
        );
        return list;
    }
    

}
