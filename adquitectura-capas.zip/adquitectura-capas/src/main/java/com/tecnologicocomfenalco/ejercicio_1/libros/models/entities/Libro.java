package com.tecnologicocomfenalco.ejercicio_1.libros.models.entities;


import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Libro {
    private int id;
    private String name;
    private int quantity;
    private List<Category_Libros> categories;
    

}


