package com.tecnologicocomfenalco.ejercicio_1.libros.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tecnologicocomfenalco.ejercicio_1.libros.models.dtos.LibroDTO;
import com.tecnologicocomfenalco.ejercicio_1.libros.service.LibroService;

@Service
public class LibroServiceImpl implements LibroService {

    @Override
    public List<LibroDTO> findAll(){
        return List.of();
    }

}
